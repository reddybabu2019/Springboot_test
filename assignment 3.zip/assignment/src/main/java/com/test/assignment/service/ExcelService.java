package com.test.assignment.service;

import com.test.assignment.model.ExcelDetails;


public interface ExcelService {
	
	public String readAllDetails();
	public void save(ExcelDetails details);
	 
	//public Details get(String appName);
	public void delete(String appName);
	public String get(String appName);

}
