package com.test.assignment.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.test.assignment.model.ExcelDetails;

@Service
@Transactional
public class ExcelServiceImpl implements ExcelService{

	@Override
	public String readAllDetails() {
		
		// TODO Auto-generated method stub
		StringBuilder str = new StringBuilder();
		XSSFWorkbook myExcelBook;
		try {
			myExcelBook = new XSSFWorkbook(new FileInputStream("input.xlsx"));
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		
		    // row and columns    
		    XSSFRow row;
		    XSSFCell cells;

		    int rowCount = myExcelSheet.getLastRowNum();
		    int colCount = myExcelSheet.getRow(0).getLastCellNum();

		    // get each row details
		    for(int r = 0; r < 6; r++) {
		    	row = myExcelSheet.getRow(r);
		    	if(row.getPhysicalNumberOfCells() == 0){
	    		break;
		    	}
		    	if(row.getCell(5).toString().equals("Win")) {
		    	for(int c = 0; c < colCount; c++) {
	    		cells  = row.getCell(c);
	    
	    		
	    		if(cells.getCellType()==CellType.BLANK) {
	    			break;
	    		}
	    			
	    		String cellval = cells.toString()+"\t";
	            str.append(cellval+"\n");
	    		System.out.println(str);
		    	}
	            }
	    	}
		
		myExcelBook.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str.toString();
	
	}

	@Override
	public void save(ExcelDetails details) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(String appName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String get(String appName) {
		// TODO Auto-generated method stub
		StringBuilder str = new StringBuilder();
		XSSFWorkbook myExcelBook;
		try {
			myExcelBook = new XSSFWorkbook(new FileInputStream("input.xlsx"));
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		
		    // row and columns    
		    XSSFRow row;
		    XSSFCell cells;

		    int rowCount = myExcelSheet.getLastRowNum();
		    int colCount = myExcelSheet.getRow(0).getLastCellNum();

		    // get each row details
		    for(int r = 0; r < 6; r++) {
		    	row = myExcelSheet.getRow(r);
		    	if(row.getPhysicalNumberOfCells() == 0){
	    		break;
		    	}
		    	if(row.getCell(0).toString().equals(appName)) {
		    	for(int c = 0; c < colCount; c++) {
	    		cells  = row.getCell(c);
	    
	    		
	    		if(cells.getCellType()==CellType.BLANK) {
	    			break;
	    		}
	    			
	    		String cellval = cells.toString()+"\t";
	            str.append(cellval+"\n");
	    		System.out.println(str);
		    	}
	           }
		    }
		  	myExcelBook.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return str.toString();

		}
		
	
}
